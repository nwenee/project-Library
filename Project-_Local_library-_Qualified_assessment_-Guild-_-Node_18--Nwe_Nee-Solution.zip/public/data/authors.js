const authors = [
  {
    id: 0,
    name: {
      first: "Lucia",
      last: "Moreno",
    },
  },
  {
    id: 1,
    name: {
      first: "Trisha",
      last: "Mathis",
    },
  },
  {
    id: 2,
    name: {
      first: "Arnold",
      last: "Marks",
    },
  },
  {
    id: 3,
    name: {
      first: "Faye",
      last: "Arnold",
    },
  },
  {
    id: 4,
    name: {
      first: "Tami",
      last: "Hurst",
    },
  },
  {
    id: 5,
    name: {
      first: "Farmer",
      last: "Stevenson",
    },
  },
  {
    id: 6,
    name: {
      first: "Hancock",
      last: "Fuller",
    },
  },
  {
    id: 7,
    name: {
      first: "Ila",
      last: "Reid",
    },
  },
  {
    id: 8,
    name: {
      first: "Susanne",
      last: "Lawson",
    },
  },
  {
    id: 9,
    name: {
      first: "Olson",
      last: "Rowland",
    },
  },
  {
    id: 10,
    name: {
      first: "Giles",
      last: "Barlow",
    },
  },
  {
    id: 11,
    name: {
      first: "Luz",
      last: "Beach",
    },
  },
  {
    id: 12,
    name: {
      first: "Chrystal",
      last: "Lester",
    },
  },
  {
    id: 13,
    name: {
      first: "Heidi",
      last: "Burks",
    },
  },
  {
    id: 14,
    name: {
      first: "Wanda",
      last: "Shannon",
    },
  },
  {
    id: 15,
    name: {
      first: "Smith",
      last: "Wiley",
    },
  },
  {
    id: 16,
    name: {
      first: "Austin",
      last: "Patton",
    },
  },
  {
    id: 17,
    name: {
      first: "Elva",
      last: "Robles",
    },
  },
  {
    id: 18,
    name: {
      first: "George",
      last: "Gentry",
    },
  },
  {
    id: 19,
    name: {
      first: "Sally",
      last: "Wooten",
    },
  },
  {
    id: 20,
    name: {
      first: "Tate",
      last: "Fletcher",
    },
  },
  {
    id: 21,
    name: {
      first: "Baxter",
      last: "Powell",
    },
  },
  {
    id: 22,
    name: {
      first: "Rodriquez",
      last: "Meyer",
    },
  },
  {
    id: 23,
    name: {
      first: "Alexander",
      last: "Cervantes",
    },
  },
  {
    id: 24,
    name: {
      first: "Snow",
      last: "Irwin",
    },
  },
  {
    id: 25,
    name: {
      first: "Matthews",
      last: "Sanders",
    },
  },
  {
    id: 26,
    name: {
      first: "Briana",
      last: "Cooke",
    },
  },
  {
    id: 27,
    name: {
      first: "Stefanie",
      last: "Justice",
    },
  },
  {
    id: 28,
    name: {
      first: "Conway",
      last: "Booker",
    },
  },
  {
    id: 29,
    name: {
      first: "Kerri",
      last: "Keith",
    },
  },
  {
    id: 30,
    name: {
      first: "Rhonda",
      last: "Hoover",
    },
  },
  {
    id: 31,
    name: {
      first: "Warren",
      last: "Potts",
    },
  },
  {
    id: 32,
    name: {
      first: "Ochoa",
      last: "Levy",
    },
  },
  {
    id: 33,
    name: {
      first: "Maddox",
      last: "Parker",
    },
  },
  {
    id: 34,
    name: {
      first: "Alfreda",
      last: "Moore",
    },
  },
  {
    id: 35,
    name: {
      first: "Mae",
      last: "Thompson",
    },
  },
  {
    id: 36,
    name: {
      first: "Riley",
      last: "Miranda",
    },
  },
  {
    id: 37,
    name: {
      first: "Cristina",
      last: "Buchanan",
    },
  },
  {
    id: 38,
    name: {
      first: "Jaime",
      last: "Carroll",
    },
  },
  {
    id: 39,
    name: {
      first: "Galloway",
      last: "Poole",
    },
  },
  {
    id: 40,
    name: {
      first: "Alyson",
      last: "Sampson",
    },
  },
  {
    id: 41,
    name: {
      first: "Warner",
      last: "Head",
    },
  },
  {
    id: 42,
    name: {
      first: "Castillo",
      last: "Sandoval",
    },
  },
  {
    id: 43,
    name: {
      first: "Duran",
      last: "Norton",
    },
  },
  {
    id: 44,
    name: {
      first: "Hensley",
      last: "Banks",
    },
  },
  {
    id: 45,
    name: {
      first: "Park",
      last: "Reeves",
    },
  },
  {
    id: 46,
    name: {
      first: "Haley",
      last: "Peterson",
    },
  },
  {
    id: 47,
    name: {
      first: "Shauna",
      last: "Hess",
    },
  },
  {
    id: 48,
    name: {
      first: "Emerson",
      last: "Gamble",
    },
  },
  {
    id: 49,
    name: {
      first: "Mcintosh",
      last: "Whitney",
    },
  },
];
